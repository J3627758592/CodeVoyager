function [n,vix] = gpSize(tree)

nt = tree.nodetyp;
v  = 1;
i  = 1;
n  = 1;
while i<=n
    if nt(v(i)) == 1
        v = [v, v(i)*2, v(i)*2+1];
    end
    i = i+1;
    n = length(v);
end

n   = length(v);
vix = v;
