function [popu,evnum] = gpRun(popuin,X,Y,Q,opt)

popun = popuin.size;
ggap  = opt(1);
pc    = opt(2);
pm    = opt(3);
tsels = opt(4);
rmode = opt(5);

%Selection
selm = gpSelection(popuin,ggap,pc,pm,tsels);

%New generation
popu = popuin;
newix = [];
nn = 1;
for i=1:size(selm,1)
    m = selm(i,3);
    %*** Crossover ***
    if m==1
        p1 = selm(i,1);
        p2 = selm(i,2);
        popu.chrom{nn} = popuin.chrom{p1};
        popu.chrom{nn}.fitness = -1;
        if nn+1<popu.size
            popu.chrom{nn+1} = popuin.chrom{p2};
            popu.chrom{nn+1}.fitness = -1;
        end
        %recombinate trees
        tree1 = popuin.chrom{p1}.tree;
        tree2 = popuin.chrom{p2}.tree;
        [tree1,tree2] = gpCrossover(tree1,tree2,rmode,popu.symbols);
        popu2.chrom{nn}.tree = tree1;
        if nn+1<=popu.size
            popu.chrom{nn+1}.tree = tree2;
        end
        %remember the new individulas
        newix = [newix nn];
        nn = nn+1;
        if nn<=popu.size
            newix = [newix nn];
            nn = nn+1;
        end
        %*** Mutation ***
    elseif m==2
        p1 = selm(i,1);
        popu.chrom{nn} = popuin.chrom{p1};
        popu.chrom{nn}.fitness = -1;
        %muatate tree
        tree1 = popu.chrom{p1}.tree;
        tree1 = gpMutate(tree1,popu.symbols);
        popu.chrom{nn}.tree = tree1;
        %remember the new individual
        newix = [newix nn];
        nn = nn+1;
        %*** Direct copy ***
    else
        p1 = selm(i,1);
        popu.chrom{nn} = popu.chrom{p1};
        nn = nn+1;
    end
end

%if opt(10)==1 -> evaluate all indv.s
if length(opt)>9 && opt(10)==1
    newix = 1:popu.size;
end

%Evaulate new indv.s
popu            = gpEvaluate(popu,newix,X,Y,Q,opt(6:9));
popu.generation = popu.generation+1;
evnum           = length(newix);
