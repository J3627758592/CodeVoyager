function [tree1,tree2] = gpCrossover(treep1,treep2,mode,symbols)

tree1 = treep1;
tree2 = treep2;
nn = [length(symbols{1}), length(symbols{2})];

switch mode
    case 1
        [~,v1] = gpSize(tree1);
        [~,v2] = gpSize(tree2);
        n      = max([tree1.maxsize, tree2.maxsize]);
        dummy1 = zeros(n,1);
        dummy2 = zeros(n,1);
        dummy1(v1) = 1;
        dummy2(v2) = 1;
        v   = find((dummy1+dummy2)==2);
        ix1 = v(floor(rand*(length(v))+1));
        ix2 = ix1;
    case 2
        [~,v] = gpSize(tree1);
        ix1 = v(floor(rand*(length(v))+1));
        [~,v] = gpSize(tree2);
        ix2 = v(floor(rand*(length(v))+1));
    otherwise
        return;
end

sub1  = gpGetsubtree(treep1,ix1);
sub2  = gpGetsubtree(treep2,ix2);
tree1 = gpInserttree(sub2,tree1,ix1,nn(2));
tree2 = gpInserttree(sub1,tree2,ix2,nn(2));
