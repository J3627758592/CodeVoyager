function popu = gpInit(popusize,maxtreedepth,symbols)

popu.generation = 1;
popu.symbols    = symbols;
popu.size       = popusize;
for i = 1:popusize
  popu.chrom{i}.fitness = 0;
  popu.chrom{i}.mse     = 0;
  popu.chrom{i}.tree    = gpGenrnd(maxtreedepth,symbols);
end
