function [mse,corcfsq,theta] = gpLsq(fss,X,Y)

% mse 
% corcfsq
% theta 
% fss 
% X,Y
%
warning off

%Calculate model terms (eval functions)
XX = zeros(length(Y),length(fss));
for i = 1:length(fss)
    XX(:,i) = eval(fss{i});
end
XX = [XX, ones(size(Y))];

%Calculate parameters and estimated output
theta = pinv(XX)*Y;
YV    = XX * theta;

% MSE:
mse = mean(sum((YV-Y).^2));
if isnan(mse)
    mse = Inf;
end

% Correlation coefficient:
c = corrcoef(YV,Y);
c = c(1,2);
if isnan(c)
    c=0;
end
corcfsq = max(0,min(c*c,1));
