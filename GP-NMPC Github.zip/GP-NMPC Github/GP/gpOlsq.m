function [vfsdel,err] = gpOlsq(fss,X,Y,limit)

vfsdel = [];
err    = [];
if limit<=0
    return;
end

warning off
XX = zeros(length(Y),length(fss));
for i = 1:length(fss)
    XX(:,i) = eval(fss{i});
end
XX = XX - repmat(mean(XX),size(XX,1),1);
YY = Y - repmat(mean(Y),size(Y,1),1);
warning on

%OLS procedure
[err]  = ols(XX,YY,0);
[~,ix] = sort(-err);

%Select:
if limit<1
    %Select based on value
    for i = 2:length(ix)
        if err(ix(i)) < limit
            vfsdel = [vfsdel, ix(i)];
        end
    end
else
    %Select based on first x pp.
    if limit<2
        limit = 2;
    end
    for i = floor(limit):length(ix)
        vfsdel = [vfsdel, ix(i)];
    end
end

%----------------------------------------------------------------------
function [err,theta] = ols(P,Y,q)
% OLS - Orthogonal Least Squares
[W,A] = qr(P,0);
%Error reduction ratios:
D = W'*W;
G = pinv(D)*W'*Y;
yty = (Y'*Y);
err = zeros(size(P,2),1);
for i = 1:size(P,2)
    err(i) = G(i)*G(i)*W(:,i)'*W(:,i)/yty;
end
%Parameter vector:
if q ~= 0
    theta = pinv(A)*G;
end
