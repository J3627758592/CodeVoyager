function s = gpStringrc(tree,ix,symbols)
%

if tree.nodetyp(ix)==1 && ix*2+1<=tree.maxsize
  sleft  = gpStringrc(tree,ix*2,symbols);
  sright = gpStringrc(tree,ix*2+1,symbols);
  s = strcat('(',sleft,')',symbols{tree.nodetyp(ix)}{tree.node(ix)}, ...
      '(',sright,')');
else
  s = symbols{tree.nodetyp(ix)}{tree.node(ix)};
end
