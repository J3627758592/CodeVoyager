function tree = gpGenrnd(maxtreedepth,symbols)

% tree = tree_genrnd(maxtreedepth,symbols)；
% tree 
% maxtreedepth 
% symbols 

nn = [length(symbols{1}), length(symbols{2})];
n  = 2^floor(maxtreedepth)-1;
vt = zeros(n,1);
vn = zeros(n,1);
for i = 1:(n-1)/2
    [vt(i),vn(i)] = gpGenrndsymb(1/2,nn);
end

for i=(n+1)/2:n
    [vt(i),vn(i)] = gpGenrndsymb(1,nn);
end

tree.maxsize = n;
tree.nodetyp = vt;
tree.node    = vn;
tree.param   = zeros(floor((tree.maxsize+1)/2),1);
tree.paramn  = 0;

%------------------------------------------------------------------
function [nodetyp,node] = gpGenrndsymb(p0,nn)


if rand<p0
    nodetyp = 2;
else
    nodetyp = 1;
end
node = randi(nn(nodetyp),1);
