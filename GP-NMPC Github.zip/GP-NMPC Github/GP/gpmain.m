
clear;clc;
warning off;

idata = readtable('data.xlsx');
idata = idata.Variables;

X        = idata(:,2:10); 
Y        = idata(:,11);   

symbols{1} = {'+','*','/'};              
symbols{2} = {'x1','x2','x3','x4','x5','x6','x7','x8','x9'};  

maxiters     = 200; 
popusize     = 20; 
maxtreedepth = 11;  

popu = gpInit(popusize,maxtreedepth,symbols);

opt  = [0.8 0.7 0.3 2 2 0.2 60 10 1 0]; 
popu = gpEvaluate(popu,1:popusize,X,Y,[],opt(6:9)); 
disp(gpResult([],0));
disp(gpResult(popu,1));


for c = 2:maxiters
  popu = gpRun(popu,X,Y,[],opt);
  disp(gpResult(popu,1));
end


[s,tree] = gpResult(popu,2);
disp(s);
