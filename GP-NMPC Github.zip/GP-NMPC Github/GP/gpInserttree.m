function tree = gpInserttree(treesrc,treedst,dstix,nvar)

% tree <- result
% treesrc 
% treedst
% dstix 
% nvar 
%

tree = treedst;
if dstix>treedst.maxsize
    return;
end

vin  = 1;
vout = dstix;
iix = 1;
while vin(iix)<=treesrc.maxsize && vout(iix)<=tree.maxsize
    tree.nodetyp(vout(iix)) = treesrc.nodetyp(vin(iix));
    tree.node(vout(iix)) = treesrc.node(vin(iix));
    vin = [vin vin(iix)*2 vin(iix)*2+1];
    vout = [vout vout(iix)*2 vout(iix)*2+1];
    iix = iix+1;
end

for i = (tree.maxsize+1)/2:tree.maxsize
    if tree.nodetyp(i)==1
        tree.nodetyp(i) = 2;
        tree.node(i) = floor(nvar*rand)+1;
    end
end
