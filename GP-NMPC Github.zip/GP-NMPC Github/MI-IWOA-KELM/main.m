warning off            
close all               
clear                  
clc                     
addpath path_kelm

res = xlsread('data.xlsx');

num_size = 0.8;                              
outdim = 1;                               
num_samples = size(res, 1);                  
%res = res(randperm(num_samples), :);         
num_train_s = round(num_size * num_samples);
f_ = size(res, 2) - outdim;                 


P_train = res(1: num_train_s, 1: f_)';
T_train = res(1: num_train_s, f_ + 1: end)';
M = size(P_train, 2);

P_test = res(num_train_s + 1: end, 1: f_)';
T_test = res(num_train_s + 1: end, f_ + 1: end)';
N = size(P_test, 2);


[p_train, ps_input] = mapminmax(P_train,0,1);
p_test = mapminmax('apply',P_test,ps_input);

[t_train, ps_output] = mapminmax(T_train,0,1);
t_test = mapminmax('apply',T_test,ps_output);

pop=30; 
Max_time=100;
dim = 2;
lb = [10,1];
ub = [100,10];
fobj = @(x) fun(x,p_train,T_train,p_test,T_test);
[Best_score,Best_pos,curve]=IWOA(pop,Max_time,lb,ub,dim,fobj); 


Regularization_coefficient = Best_pos(1);
Kernel_para = Best_pos(2);
Kernel_type = 'rbf';

[net,OutputWeight] = kelmTrain(p_train,t_train,Regularization_coefficient,Kernel_type,Kernel_para);


InputWeight = OutputWeight;
t_sim1 = kelmPredict(p_train,InputWeight,Kernel_type,Kernel_para,p_train);
t_sim2 = kelmPredict(p_train,InputWeight,Kernel_type,Kernel_para,p_test);


T_sim1 = mapminmax('reverse', t_sim1, ps_output);
T_sim2 = mapminmax('reverse', t_sim2, ps_output);

figure;
plotregression(T_test,T_sim2,'Regression');
set(gcf,'color','w')
figure;
ploterrhist(T_test-T_sim2,'Error histogram');
set(gcf,'color','w')

figure
plot(curve,'linewidth',1.5);
grid on;
title('IWOA-KELM', 'FontSize', 10);
xlabel('Iterations', 'FontSize', 10)
ylabel('Fitness', 'FontSize', 10)

set(gcf,'color','w')


error1 = sqrt(sum((T_sim1 - T_train).^2)./M);
error2 = sqrt(sum((T_test - T_sim2).^2)./N);



R1 = 1 - norm(T_train - T_sim1)^2 / norm(T_train - mean(T_train))^2;
R2 = 1 - norm(T_test -  T_sim2)^2 / norm(T_test -  mean(T_test ))^2;

%%
% MSE
mse1 = sum((T_sim1 - T_train).^2)./M;
mse2 = sum((T_sim2 - T_test).^2)./N;
%%
%RPD 
SE1=std(T_sim1-T_train);
RPD1=std(T_train)/SE1;

SE=std(T_sim2-T_test);
RPD2=std(T_test)/SE;
%% MAE
MAE1 = mean(abs(T_train - T_sim1));
MAE2 = mean(abs(T_test - T_sim2));
%% MAPE
MAPE1 = mean(abs((T_train - T_sim1)./T_train));
MAPE2 = mean(abs((T_test - T_sim2)./T_test));


figure
plot(1:M,T_train,'r-*',1:M,T_sim1,'b-o','LineWidth',1.5)
legend('Actual','IWOA-KELM')
xlabel('Test data (No.)')
ylabel('Predict results')
string={'Comparison of training set prediction results';['(R^2 =' num2str(R1) ' RMSE= ' num2str(error1) ' MSE= ' num2str(mse1) ' RPD= ' num2str(RPD1) ')' ]};
title(string)
set(gcf,'color','w')

figure
plot(1:N,T_test,'r-*',1:N,T_sim2,'b-o','LineWidth',1.5)
legend('Actual','IWOA-KELM')
xlabel('Test data (No.)')
ylabel('Predict results')
string={'Comparison of test set prediction results';['(R^2 =' num2str(R2) ' RMSE= ' num2str(error2)  ' MSE= ' num2str(mse2) ' RPD= ' num2str(RPD2) ')']};
title(string)
set(gcf,'color','w')


figure  
ERROR3=T_test-T_sim2;
plot(T_test-T_sim2,'b-*','LineWidth',1.5)
xlabel('Training data (No.)')
ylabel('Error of predict')
title('Error of test')
grid on;
legend('IWOA-KELM predict error')
set(gcf,'color','w')

figure
plot(T_train,T_sim1,'*r');
xlabel('Actual value')
ylabel('Predict value')
string = {'Effect of training';['R^2_c=' num2str(R1)  '  RMSEC=' num2str(error1) ]};
title(string)
hold on ;h=lsline;
set(h,'LineWidth',1,'LineStyle','-','Color',[1 0 1])
set(gcf,'color','w')

figure
plot(T_test,T_sim2,'ob');
xlabel('Actual value')
ylabel('Predict value')
string1 = {'Effect of test';['R^2_p=' num2str(R2)  '  RMSEP=' num2str(error2) ]};
title(string1)
hold on ;h=lsline();
set(h,'LineWidth',1,'LineStyle','-','Color',[1 0 1])
set(gcf,'color','w')

R3=(R1+R2)./2;
error3=(error1+error2)./2;

tsim=[T_sim1,T_sim2]';
S=[T_train,T_test]';
figure
plot(S,tsim,'ob');
xlabel('Actual value')
ylabel('Predict value')
string1 = {'All sample fitting prediction plots';['R^2_p=' num2str(R3)  '  RMSEP=' num2str(error3) ]};
title(string1)
hold on ;h=lsline();
set(h,'LineWidth',1,'LineStyle','-','Color',[1 0 1])
set(gcf,'color','w')

disp(['-----------------------Error calculation--------------------------'])
disp(['Evaluation result：'])
disp(['MAE：',num2str(MAE2)])
disp(['MSE：       ',num2str(mse2)])
disp(['RMSEP：  ',num2str(error2)])
disp(['R^2：  ',num2str(R2)])
disp(['RPD：  ',num2str(RPD2)])
disp(['MAPE：  ',num2str(MAPE2)])
grid