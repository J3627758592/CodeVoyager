
close all            
clear                   
clc                  
datatable = xlsread("Concrete_Data.xls");
features = datatable(:,1:end-1);
y = datatable(:,end);
k = 5;       
[save_index1, mic] = mi_select(features, y, k);
disp('MI：')
disp(save_index1)
MIselectfeature = features(:,save_index1);
figure
bar(mic,0.75,'red')
xlabel('Num of featrues')
ylabel('MI values')
for i = 1:length(mic)
    text(i,mic(i),num2str(mic(i),"%.2f "),...
    'HorizontalAlignment','center',...
    'VerticalAlignment','bottom')
end